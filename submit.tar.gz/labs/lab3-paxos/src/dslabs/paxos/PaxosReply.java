package dslabs.paxos;

import dslabs.framework.Message;
import lombok.Data;

@Data
public final class PaxosReply implements Message {
    // Your code here...
}
