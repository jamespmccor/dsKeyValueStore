package dslabs.paxos;

public class DebugUtils {
  public static final boolean VoteTracker_INVARIANTS = true;
  public static final boolean PaxosLog_INVARIANTS = true;
  public static final boolean PaxosServer_DEBUG = false;
  public static final boolean PaxosClient_DEBUG = false;
}
