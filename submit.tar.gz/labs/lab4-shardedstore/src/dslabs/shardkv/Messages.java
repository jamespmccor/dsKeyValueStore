package dslabs.shardkv;

import dslabs.framework.Message;
import lombok.Data;

@Data
final class ShardStoreRequest implements Message {
    // Your code here...
}

@Data
final class ShardStoreReply implements Message {
    // Your code here...
}

// Your code here...
